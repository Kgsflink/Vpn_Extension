const toggleSwitch = document.getElementById('toggleSwitch');
const statusLabel = document.getElementById('status');
const ipAddressLabel = document.getElementById('ip-address');

// Load initial state
chrome.storage.sync.get('torEnabled', (data) => {
  toggleSwitch.checked = data.torEnabled;
  updateStatus(data.torEnabled);
});

// When the toggle is clicked, send a message to the background script
toggleSwitch.addEventListener('change', () => {
  chrome.runtime.sendMessage({ action: 'toggleTor' }, (response) => {
    updateStatus(response.status);
  });
});

function updateStatus(isEnabled) {
  statusLabel.textContent = `Status: ${isEnabled ? 'On' : 'Off'}`;
}

// Get the live IP address
fetch('https://api.ipify.org?format=json')
  .then(response => response.json())
  .then(data => {
    ipAddressLabel.textContent = data.ip;
  })
  .catch(err => console.error('Error fetching IP:', err));
