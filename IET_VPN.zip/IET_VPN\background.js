chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ torEnabled: false });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "toggleTor") {
    chrome.storage.sync.get("torEnabled", (data) => {
      const newStatus = !data.torEnabled;
      chrome.storage.sync.set({ torEnabled: newStatus }, () => {
        if (newStatus) {
          startTorProxy();
        } else {
          stopTorProxy();
        }
        sendResponse({ status: newStatus });
      });
    });
    return true;
  }
});

function startTorProxy() {
  chrome.proxy.settings.set(
    {
      value: {
        mode: "fixed_servers",
        rules: {
          singleProxy: {
            scheme: "socks5",
            host: "127.0.0.1",
            port: 9050
          }
        }
      },
      scope: "regular"
    },
    () => console.log("Tor Proxy Enabled")
  );
}

function stopTorProxy() {
  chrome.proxy.settings.clear(
    { scope: "regular" },
    () => console.log("Tor Proxy Disabled")
  );
}
