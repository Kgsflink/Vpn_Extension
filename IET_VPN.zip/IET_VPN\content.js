
function removeAds() {
    const adSelectors = ['.ad-container', '.ytp-ad-module', '.video-ads', '.ytp-ad-overlay-container', 'ytd-promoted-sparkles-web-renderer', 'ytd-display-ad-renderer', 'ytd-promoted-video-renderer', 'iframe[title*="ad"]', '[id*="ad"]', '[class*="ad"]', '[aria-label*="advertisement"]', '.ad', '.ads', '.sponsored-content', '.sponsored-link'];
  
    adSelectors.forEach(selector => {
      document.querySelectorAll(selector).forEach(ad => ad.remove());
    });
  }
  
  function runAdBlocker() {
    chrome.storage.sync.get(['adBlockEnabled'], function(result) {
      if (result.adBlockEnabled) {
        removeAds();
      }
    });
  }
  
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'toggleAdBlock') {
      if (message.enabled) {
        runAdBlocker();
      }
    }
  });
  
  setInterval(runAdBlocker, 2000);
  runAdBlocker();
  